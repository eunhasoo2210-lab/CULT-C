import test from 'node:test';
import assert from 'node:assert/strict';
import { residentCards } from '../src/lib/resident-cards.ts';

const countBy = (cards, field) => cards.reduce((counts, card) => ({ ...counts, [card[field]]: (counts[card[field]] ?? 0) + 1 }), {});
test('40 unique cards; both groups have equal numbers of girls and boys', () => {
  assert.equal(residentCards.length, 40);
  assert.equal(new Set(residentCards.map(c => c.id)).size, 40);
  assert.deepEqual(countBy(residentCards, 'gender'), { '여': 20, '남': 20 });
  assert.deepEqual(countBy(residentCards.filter(c => c.group === '다문화'), 'gender'), { '여': 16, '남': 16 });
  assert.deepEqual(countBy(residentCards.filter(c => c.group === '한국'), 'gender'), { '여': 4, '남': 4 });
});
test('user allocation retained: regions 6/6/5/5/5/5 and each booth and strength 8', () => {
  const cards = residentCards.filter(c => c.group === '다문화');
  assert.deepEqual(countBy(cards, 'region'), { '동남아': 6, '아시아': 6, '유럽': 5, '남미': 5, '북미(호주 포함)': 5, '아프리카': 5 });
  assert.deepEqual(countBy(cards, 'booth'), { '음식': 8, '공연': 8, '전통 놀이': 8, '꾸미기': 8 });
  assert.deepEqual(countBy(cards, 'strength'), { '통역': 8, '대화': 8, '용기': 8, '배려': 8 });
  const pairs = cards.reduce((counts, c) => ({ ...counts, [c.booth + c.strength]: (counts[c.booth + c.strength] ?? 0) + 1 }), {});
  assert.equal(Object.keys(pairs).length, 16);
  assert.ok(Object.values(pairs).every(count => count === 2));
});
test('no name or country fields; user first and last card preserved', () => {
  assert.ok(residentCards.every(c => !('name' in c) && !('country' in c)));
  assert.deepEqual(residentCards[0], {id:'D01',group:'다문화',region:'동남아',gender:'여',booth:'음식',strength:'통역'});
  assert.deepEqual(residentCards[39], {id:'K08',group:'한국',region:'한국',gender:'남',booth:'꾸미기',strength:'정보 찾기'});
});
