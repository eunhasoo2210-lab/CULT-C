import test from 'node:test';
import assert from 'node:assert/strict';
import { complete, gameReducer as reduce, initialGame, hand } from '../src/lib/festival-game.ts';

const start = (count=3) => reduce(reduce(initialGame(), {type:'count',count}), {type:'start'});
function put(game, booth, pairs) {
  for (const [slot,card] of pairs) {
    game = reduce(game,{type:'select',card});
    game = reduce(game,{type:'place',booth,slot});
  }
  return game;
}
function two(game, booth) {
  const available = hand(game);
  return reduce(put(game,booth,[[0,available[0]],[1,available[1]]]),{type:'commit'});
}

test('one card ends turn; one card alone is not a complete booth',()=>{
  let g=put(start(),0,[[0,'카드 1']]);
  assert.equal(g.turn,0);
  assert.equal(g.villages[0][0][0],null);
  g=reduce(g,{type:'commit'});
  assert.equal(g.turn,1);
  assert.equal(g.villages[0][0][0],'카드 1');
  assert.equal(complete(g.villages[0][0]),false);
});
test('two cards in one booth complete it, but another booth is blocked',()=>{
  let g=put(start(4),0,[[0,'카드 1']]);
  g=reduce(g,{type:'select',card:'카드 2'});
  g=reduce(g,{type:'place',booth:1,slot:1});
  assert.equal(g.draft.booth,0);
  assert.equal(g.draft.slots[1],null);
  g=reduce(g,{type:'place',booth:0,slot:1});
  assert.equal(hand(g).length,6);
  g=reduce(g,{type:'commit'});
  assert.equal(g.turn,1);
  assert.equal(complete(g.villages[0][0]),true);
  assert.deepEqual(g.villages[0][1],[null,null]);
});
test('removing multiple cards across booths preserves turn and returns cards',()=>{
  let g=start();
  g={...g,villages:g.villages.map((v,i)=>i===0?[['카드 1','카드 2'],['카드 3','카드 4'],...v.slice(2)]:v)};
  g=reduce(g,{type:'remove',booth:0,slot:0});
  g=reduce(g,{type:'remove',booth:1,slot:1});
  assert.equal(g.turn,0);
  assert.equal(hand(g).length,6);
  assert.equal(complete(g.villages[0][0]),false);
  assert.equal(complete(g.villages[0][1]),false);
  g=reduce(put(g,2,[[0,'카드 1'],[1,'카드 4']]),{type:'commit'});
  assert.equal(g.turn,1);
  assert.equal(complete(g.villages[0][2]),true);
});
test('cancel draft releases cards and allows another booth without undoing removals',()=>{
  let g=put(start(),0,[[0,'카드 1']]);
  g=reduce(g,{type:'cancel'});
  assert.equal(hand(g).length,8);
  g=put(g,1,[[0,'카드 1']]);
  assert.equal(g.draft.booth,1);
  assert.equal(g.turn,0);
});
for(const count of [3,4]) test(`${count} players: first winner pauses, continuation skips winner, second place ends`,()=>{
  let g=start(count);
  for(let booth=0;booth<4;booth++) {
    for(let player=0;player<count;player++) {
      if(player===0)g=two(g,booth); else if(g.phase==='playing')g=reduce(g,{type:'pass'});
    }
  }
  assert.equal(g.phase,'celebrating');
  assert.deepEqual(g.ranks,[0]);
  assert.equal(g.turn,0);
  const paused=reduce(g,{type:'pass'});
  assert.equal(paused,g);
  g=reduce(g,{type:'continue'});
  assert.equal(g.turn,1);
  for(let booth=0;booth<4;booth++) {
    g=two(g,booth);
    if(booth<3) {
      while(g.turn!==1) { assert.notEqual(g.turn,0); g=reduce(g,{type:'pass'}); }
    }
  }
  assert.deepEqual(g.ranks,[0,1]);
  assert.equal(g.phase,'celebrating');
  assert.equal(reduce(g,{type:'continue'}),g);
  g=reduce(g,{type:'end'});
  assert.equal(g.phase,'ended');
  assert.equal(reduce(g,{type:'remove',booth:0,slot:0}),g);
});
test('end immediately after first victory and reset clear all state',()=>{
  let g=start();
  for(let booth=0;booth<4;booth++) {
    g=two(g,booth);
    if(booth<3) {g=reduce(g,{type:'pass'});g=reduce(g,{type:'pass'});}
  }
  g=reduce(g,{type:'end'});
  assert.deepEqual(g.ranks,[0]);
  assert.equal(g.phase,'ended');
  assert.deepEqual(reduce(g,{type:'reset'}),initialGame());
});
