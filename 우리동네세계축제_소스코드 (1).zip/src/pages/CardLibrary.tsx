import { useState } from 'react';
import { Globe2, Flag, Users, Utensils, Music, Puzzle, Palette, Languages, MessagesSquare, Shield, HeartHandshake, Search, SlidersHorizontal } from 'lucide-react';
import { residentCards, type ResidentCard } from '../lib/resident-cards';
import './cards.css';

const boothIcons = { '음식': Utensils, '공연': Music, '전통 놀이': Puzzle, '꾸미기': Palette };
const strengthIcons = { '통역': Languages, '대화': MessagesSquare, '용기': Shield, '배려': HeartHandshake, '정보 찾기': Search };

export function ResidentCardFace({ card }: { card: ResidentCard }) {
  const Booth = boothIcons[card.booth as keyof typeof boothIcons];
  const Strength = strengthIcons[card.strength as keyof typeof strengthIcons];
  return <article className={`resident-face ${card.group === '한국' ? 'korean-face' : ''}`} aria-label={`${card.id} ${card.region} 성별 ${card.gender} 부스 ${card.booth} 극복 ${card.strength}`}>
    <div className="resident-inner">
      <header className="card-face-header"><b>{card.id}</b><span>{card.group === '한국' ? '한국' : '다문화'}</span></header>
      <div className="card-region-art">
        <Globe2 className="card-globe" strokeWidth={0.8} aria-hidden="true"/>
        <span className="card-orbit orbit-one" aria-hidden="true"/><span className="card-orbit orbit-two" aria-hidden="true"/>
        <span className="card-region-caption">함께하는 지역</span>
        <h3>{card.region === '북미(호주 포함)' ? <>북미<span className="region-extra">호주 포함</span></> : card.region}</h3>
      </div>
      <dl className="card-attributes">
        <div className="card-gender"><dt>성별</dt><dd>{card.gender}</dd></div>
        <div><dt>부스 성향</dt><dd><Booth aria-hidden="true"/>{card.booth}</dd></div>
        <div><dt>극복 성향</dt><dd><Strength aria-hidden="true"/>{card.strength}</dd></div>
      </dl>
      <footer className="card-face-footer"><Flag size={10} aria-hidden="true"/> 우리 동네 세계 축제</footer>
    </div>
  </article>;
}

export default function CardLibrary() {
  const [group, setGroup] = useState('전체');
  const [region, setRegion] = useState('전체');
  const [booth, setBooth] = useState('전체');
  const filtered = residentCards.filter(c => (group === '전체' || c.group === group) && (region === '전체' || c.region === region) && (booth === '전체' || c.booth === booth));
  const female = filtered.filter(c => c.gender === '여').length;
  return <section className="card-library" aria-labelledby="card-library-title">
    <div className="card-library-screen">
      <div className="library-heading"><div><p className="small-label">지역과 성향으로 만나는 우리 마을 주민들</p><h2 id="card-library-title">축제를 함께 만들 40장의 카드</h2><p>이름과 국가는 빼고, 지역·성별·두 가지 성향을 담았어요.</p></div><span className="library-seal"><Users size={23} aria-hidden="true"/><b>여 20 · 남 20</b><span>성별 균등 배분</span></span></div>
      <div className="deck-summary"><span className="summary-diverse"><i/> 다문화 카드 <b>32장</b><small>여 16 · 남 16</small></span><span className="summary-korean"><i/> 한국 카드 <b>8장</b><small>여 4 · 남 4</small></span></div>
      <div className="card-filter-bar"><SlidersHorizontal size={17} aria-hidden="true"/><div className="deck-group-options" aria-label="카드 구분">{['전체','다문화','한국'].map(g=><button key={g} className={group===g?'selected':''} aria-pressed={group===g} onClick={()=>setGroup(g)}>{g}{g==='전체'?' 40':g==='다문화'?' 32':' 8'}</button>)}</div>
        <label><span className="sr-only">지역 필터</span><select value={region} onChange={e=>setRegion(e.target.value)}><option value="전체">모든 지역</option>{[...new Set(residentCards.map(c=>c.region))].map(r=><option key={r}>{r}</option>)}</select></label>
        <label><span className="sr-only">부스 성향 필터</span><select value={booth} onChange={e=>setBooth(e.target.value)}><option value="전체">모든 부스 성향</option>{Object.keys(boothIcons).map(b=><option key={b}>{b}</option>)}</select></label>
      </div>
      <div className="library-result" role="status"><span><b>{filtered.length}장</b>을 보고 있어요</span><span>여 {female} · 남 {filtered.length - female}</span></div>
      {filtered.length ? <div className="resident-deck">{filtered.map(card=><ResidentCardFace key={card.id} card={card}/>)}</div> : <div className="empty-deck"><Search size={28} aria-hidden="true"/><h3>조건에 맞는 카드가 없어요</h3><p>지역이나 부스 성향을 바꿔 보세요.</p><button onClick={()=>{setGroup('전체');setRegion('전체');setBooth('전체');}}>전체 카드 보기</button></div>}
      <aside className="card-allocation-note"><h3>배분에 관해 알아 두세요</h3><p>주신 표의 지역·부스 성향·극복 성향은 그대로 유지했어요. 각 묶음에서 홀수 번호는 여, 짝수 번호는 남으로 배정했어요. 성별에 따른 색상이나 능력 차이는 없어요.</p><p>지역 묶음은 이 게임의 분류예요. 3인·4인 분배 방법은 아직 미정이며, 준비판의 연습용 카드와는 아직 연결하지 않았어요.</p></aside>
    </div>
  </section>;
}
