import { useEffect, useReducer, useRef, useState, type CSSProperties } from 'react';
import { Flag, Users, ArrowRight, Sparkles, Check, Utensils, Music, Puzzle, Palette, BookOpen, Layers, RotateCcw, Trophy } from 'lucide-react';
import { useSearchParams } from 'react-router';
import { complete, gameReducer, hand, initialGame } from '../lib/festival-game';
import CardLibrary from './CardLibrary';
import './festival.css';

const booths = [
  { name: '음식', icon: Utensils, color: '#e18a67', light: '#fcf0e8', desc: '맛있는 마음을 나눠요' },
  { name: '공연', icon: Music, color: '#c49b35', light: '#fcf5df', desc: '우리의 무대를 만들어요' },
  { name: '전통 놀이', icon: Puzzle, color: '#4b9382', light: '#eaf4ef', desc: '함께 놀며 가까워져요' },
  { name: '꾸미기', icon: Palette, color: '#8980b8', light: '#f0edf8', desc: '마을을 알록달록하게' },
];
const tabs = ['축제 준비판', '게임 규칙', '주민 카드'] as const;
type Tab = typeof tabs[number];

function Stall({ index, complete }: { index: number; complete: boolean }) {
  const Icon = booths[index].icon;
  return <div className={`stall ${complete ? 'stall-done' : ''}`} aria-hidden="true">
    <div className="stall-flag"/><div className="stall-roof"/><div className="stall-valance"/>
    <div className="stall-body"><Icon size={31} strokeWidth={1.7}/></div><div className="stall-counter"/>
    {complete && <span className="stall-check"><Check size={14}/></span>}
  </div>;
}

export default function Home() {
  const [game, dispatch] = useReducer(gameReducer, undefined, initialGame);
  const { count, turn, round, phase, ranks, draft } = game;
  const started = phase !== 'setup';
  const playing = phase === 'playing';
  const progress = game.villages.map(v => v.map(complete));
  const availableCards = hand(game);
  const draftCount = draft?.slots.filter(Boolean).length ?? 0;
  const [params, setParams] = useSearchParams();
  const tab: Tab = params.get('view') === 'cards' ? '주민 카드' : params.get('view') === 'rules' ? '게임 규칙' : '축제 준비판';
  function setTab(next: Tab) {
    setParams(old => {
      const updated = new URLSearchParams(old);
      if (next === '축제 준비판') updated.delete('view');
      else updated.set('view', next === '주민 카드' ? 'cards' : 'rules');
      return updated;
    }, { preventScrollReset: true });
  }
  const [resetPrompt, setResetPrompt] = useState(false);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const victoryRef = useRef<HTMLDialogElement>(null);
  const startRef = useRef<HTMLButtonElement>(null);
  const previousPhase = useRef(phase);
  useEffect(() => {
    if (resetPrompt) dialogRef.current?.showModal(); else dialogRef.current?.close();
  }, [resetPrompt]);
  useEffect(() => {
    if (phase === 'celebrating') victoryRef.current?.showModal(); else victoryRef.current?.close();
    if (phase === 'setup' && previousPhase.current !== 'setup') startRef.current?.focus();
    previousPhase.current = phase;
  }, [phase]);
  const done = progress[turn].filter(Boolean).length;
  function reset() { dispatch({ type: 'reset' }); setResetPrompt(false); }

  return <main className="festival-app">
    <a className="skip-link" href="#game-content">게임 내용으로 건너뛰기</a>
    <header className="festival-header">
      <a className="brand" href="/" aria-label="우리 동네 세계 축제 처음으로"><span className="brand-icon"><Flag size={21}/></span><span>우리 동네 <b>세계 축제</b></span></a>
      <span className="draft-label"><span/> 함께 만드는 보드게임 <b>초안</b></span>
    </header>
    <div className="festival-container" id="game-content">
      <section className="villages villages-top" aria-label="전체 마을 진행도">
        <div className="section-heading"><h2><Users size={18}/> 마을별 축제 진행도</h2>{started ? <button className="text-button" onClick={()=>setResetPrompt(true)}><RotateCcw size={13}/> 처음부터</button> : <span className="small-label">{count}개 마을이 함께해요</span>}</div>
        <div className="village-list">{Array.from({length:count},(_,i)=>{
          const rank = ranks.indexOf(i);
          return <div key={i} className={`village ${playing&&i===turn?'current':''} ${rank>=0?'ranked':''}`}>
            <span className="village-number">{rank>=0?<Trophy size={17}/>:i+1}</span>
            <div><h3>{i+1}번 마을 {rank>=0?<small>{rank+1}위 확정</small>:playing&&i===turn?<small>현재 차례</small>:null}</h3>
              <div className="village-dots">{booths.map((b,j)=><span key={j} style={{background:progress[i][j]?b.color:undefined}} aria-label={`${b.name} ${progress[i][j]?'완성':'준비 중'}`}/>)}</div>
            </div><b>{progress[i].filter(Boolean).length}<span> / 4</span></b>
          </div>;
        })}</div>
      </section>
      <section className="intro"><div><p className="intro-note"><span/> 서로 다른 우리가 함께 만드는 하나의 축제</p><h1>우리 마을에 축제가 열려요!</h1><p className="intro-description">주민들과 힘을 모아 네 가지 부스를 만들어요.<br className="mobile-break"/> 축제를 가장 먼저 완성하는 마을이 승리해요.</p></div><div className="intro-stamp"><Flag size={23}/><span>함께 준비하는<br/><strong>3–4인 보드게임</strong></span></div></section>
      <nav className="festival-tabs" aria-label="게임 메뉴">{tabs.map((t,i)=>{const Icon=[Flag,BookOpen,Layers][i];return <button key={t} aria-current={tab===t?'page':undefined} onClick={()=>setTab(t)} className={tab===t?'active':''}><Icon size={17}/>{t}</button>;})}<span className="prototype-tag">기본 틀 미리보기</span></nav>
      {tab==='축제 준비판' && <div className="game-workspace">
        <section className="play-layout">
          <div className="board">
            <div className="board-heading"><div><p className="small-label">{playing ? `${turn+1}번 마을의 차례` : phase==='setup'?'축제를 상상해 보세요':'이번 축제의 기록'}</p><h2>{started ? `${turn+1}번 마을 축제 준비판` : '우리 마을 축제 준비판'}</h2></div><span className="completion"><b>{done}</b> / 4 <span>완성</span></span></div>
            <div className="bunting" aria-hidden="true">{Array.from({length:13},(_,i)=><i key={i} style={{background:booths[i%4].color}}/>)}</div>
            <div className="booth-grid card-booth-grid">{booths.map((b,i)=><article key={b.name} className={`booth card-booth ${progress[turn][i]?'complete':''} ${draft?.booth===i?'draft-booth':''}`} style={{'--booth':b.color,'--booth-light':b.light} as CSSProperties}>
              <Stall index={i} complete={progress[turn][i]}/><h3>{b.name}</h3><p>{b.desc}</p>
              <div className="card-slots">{['국가 담당','종목 담당'].map((role,slot)=>{
                const staged = draft?.booth===i ? draft.slots[slot] : null;
                const card = staged ?? game.villages[turn][i][slot];
                const blocked = !playing || (!card && (!game.selected || (!!draft && draft.booth!==i)));
                return <button key={role} className={`card-slot ${card?'filled':''} ${staged?'staged':''}`} disabled={blocked} onClick={()=>dispatch({type:card?'remove':'place',booth:i,slot})} aria-label={`${b.name} ${role} ${card?'카드 빼기':'카드 넣기'}`}>
                  <span className="slot-role">{role}</span>
                  {card?<><Layers size={21} aria-hidden="true"/><strong>{card}</strong><span className="slot-hint">{staged?'넣기 대기 · 취소':playing?'눌러서 빼기':'배치 완료'}</span></>:<><span className="slot-plus" aria-hidden="true">＋</span><span className="slot-hint">{game.selected&&playing?'여기에 놓기':'카드 1장'}</span></>}
                </button>;
              })}</div>
              <span className="booth-status">{progress[turn][i]?<><Check size={13}/> 완성했어요</>:draft?.booth===i?'넣기 확정 전':`${game.villages[turn][i].filter(Boolean).length} / 2장 배치`}</span>
            </article>)}</div>
            <div className="board-note"><Sparkles size={16}/><span>국가 담당 1장 + 종목 담당 1장 = 부스 완성. 한 턴에는 한 부스에만 넣어요.</span></div>
          </div>
          <aside className="game-sidebar">
            <section className="setup-panel">
              {phase==='ended' || phase==='celebrating' ? <>
                <span className="panel-symbol"><Trophy size={24}/></span><p className="panel-eyebrow">{phase==='ended'?'이번 게임의 결과':'축제가 열렸어요!'}</p><h2>{phase==='ended'?'축제 준비를 마쳤어요':'축하합니다!'}</h2>
                <ol className="ranking-list">{ranks.map((player,index)=><li key={player}><b>{index+1}위</b> {player+1}번 마을</li>)}</ol>
                <button className="primary-button" onClick={()=>setResetPrompt(true)}>새 게임 준비하기 <RotateCcw size={17}/></button>
              </> : started ? <>
                <span className="panel-symbol"><Flag size={24}/></span><p className="panel-eyebrow">{round}라운드 · {ranks.length?'2위 결정전':`${count}개 마을`}</p><h2>{turn+1}번 마을의 차례예요</h2>
                <p>다른 부스의 카드는 여러 장 뺄 수 있어요. 한 부스에 1~2장을 넣으면 턴이 끝나요.</p>
                {draft ? <div className="turn-commit"><span>{booths[draft.booth].name} 부스에 {draftCount}장 넣기 대기</span><button className="primary-button" onClick={()=>dispatch({type:'commit'})}>카드 {draftCount}장 넣고 턴 종료 <ArrowRight size={17}/></button><button className="secondary-panel-button" onClick={()=>dispatch({type:'cancel'})}>넣기 선택 취소</button></div>
                  : <button className="secondary-panel-button pass-button" onClick={()=>dispatch({type:'pass'})}>카드 없이 턴 넘기기 <ArrowRight size={16}/></button>}
                <span className="panel-footnote">‘넣고 턴 종료’를 누르면 다음 마을로 넘어가요.</span>
              </> : <>
                <span className="panel-symbol"><Users size={24}/></span><p className="panel-eyebrow">축제 준비, 시작해 볼까요?</p><h2>몇 명이 함께하나요?</h2><p>한 화면에서 차례를 주고받으며<br/>각자의 마을을 완성해요.</p>
                <div className="player-options" aria-label="참여 인원">{[3,4].map(n=><button key={n} onClick={()=>dispatch({type:'count',count:n})} aria-pressed={count===n} className={count===n?'selected':''}><Users size={18}/>{n}인{count===n&&<Check size={15}/>}</button>)}</div>
                <button ref={startRef} className="primary-button" onClick={()=>dispatch({type:'start'})}>축제 준비하기 <ArrowRight size={18}/></button><span className="panel-footnote">서로 다른 {count}개의 마을이 참여해요.</span>
              </>}
            </section>
            <section className="goal-note"><span className="goal-icon"><Trophy size={21}/></span><div><h3>가장 먼저 축제를 개최해요</h3><p>두 카드로 부스를 완성해요.<br/>네 부스가 완성되면 축제를 개최해요!</p></div></section>
          </aside>
        </section>
        <section className="hand-panel" aria-label="현재 마을의 손 카드" hidden={!started}>
          <div className="section-heading"><h2><Layers size={18}/> {started?`${turn+1}번 마을의 손 카드`:'배치 연습용 카드'}</h2><span className="small-label">{availableCards.length}장 · 모두 예시 카드</span></div>
          <p className="hand-help">{playing?'카드 선택 → 국가 담당 또는 종목 담당 칸 선택 → 한 부스에 넣고 턴 종료':'시작하면 예시 카드 8장으로 배치를 연습할 수 있어요.'}</p>
          <div className="hand-cards">{availableCards.map(card=><button key={card} className={`hand-card ${game.selected===card?'selected':''}`} disabled={!playing} aria-pressed={game.selected===card} onClick={()=>dispatch({type:'select',card})}><span>예시 주민</span><Users size={24} aria-hidden="true"/><strong>{card}</strong><small>국가·성향 미정</small>{game.selected===card&&<Check size={14} className="hand-selected-check"/>}</button>)}</div>
          {draft&&<div className="hand-commit"><span>{booths[draft.booth].name} 부스 · {draftCount}장 넣기 대기</span><button onClick={()=>dispatch({type:'cancel'})}>선택 취소</button><button onClick={()=>dispatch({type:'commit'})}>카드 {draftCount}장 넣고 턴 종료 <ArrowRight size={15}/></button></div>}
          <p className="game-notice" role="status">{game.notice || '실제 카드 구성과 조건 검사는 아직 적용하지 않았어요.'}</p>
          <p className="hand-disclaimer">각 마을의 예시 카드 8장은 배치 연습용이에요. 실제 분배 장수와 국가·성향 조건은 미정이에요.</p>
        </section>
      </div>}
      {tab==='게임 규칙' && <section className="reference-panel">
        <span className="small-label">지금 정한 기본 약속</span><h2>함께 준비하고, 먼저 완성해요.</h2>
        <div className="rule-grid"><article><Users/><h3>3명 또는 4명이 참여해요</h3><p>플레이어는 각자 하나의 마을을 맡아요. 순서대로 차례를 진행해요.</p></article><article><Layers/><h3>두 카드로 부스를 완성해요</h3><p>음식, 공연, 전통 놀이, 꾸미기 부스마다 국가 담당 1장과 종목 담당 1장을 넣어요.</p></article><article><Trophy/><h3>축제를 먼저 개최하면 승리해요</h3><p>네 부스를 먼저 완성하면 1위예요. 이후 종료하거나, 1위 마을을 제외하고 2위 결정전을 이어갈 수 있어요.</p></article></div>
        <div className="draft-note"><h3>한 턴에 할 수 있는 행동</h3><p>자기 부스에 있던 카드는 여러 부스에서 여러 장 뺄 수 있어요. 넣을 때는 한 부스에만 1장 또는 2장을 넣을 수 있어요. 카드를 고르고 빈칸에 놓은 뒤 ‘카드 넣고 턴 종료’를 누르면 배치가 확정되고 즉시 다음 마을로 넘어가요. 두 칸이 모두 차면 해당 부스가 완성돼요. 완성된 부스에서 카드를 빼면 다시 미완성 상태가 돼요.</p></div>
        <div className="draft-note"><h3>아직 정하지 않은 내용</h3><p>주민 카드 40장의 인원별 분배, 국가·성향 조건, 주사위·이사·방해 카드는 미적용이에요. 준비판에서는 구별된 예시 카드 8장으로 배치만 연습해요. 넣기 없이 턴을 넘기는 버튼은 체험을 위한 임시 기능이에요. 2위가 결정되면 이 체험판은 종료돼요.</p></div>
        <p className="terminology">용어는 ‘지역’과 ‘꾸미기’로 통일했어요. ‘국가 담당’과 ‘종목 담당’은 부스의 카드 자리 이름이에요.</p>
      </section>}
      {tab==='주민 카드' && <CardLibrary/>}
      <footer className="festival-footer"><span><Flag size={14}/> 우리 동네 세계 축제</span><p>규칙을 함께 다듬는 틀이에요. 진행 상황은 새로고침하면 초기화돼요.</p></footer>
    </div>
    <dialog ref={dialogRef} className="reset-dialog" aria-labelledby="reset-title" onCancel={()=>setResetPrompt(false)}><h2 id="reset-title">새 게임을 준비할까요?</h2><p>지금까지 배치한 카드와 차례, 순위가 초기화돼요.</p><div><button onClick={()=>setResetPrompt(false)}>계속하기</button><button onClick={reset}>초기화하기</button></div></dialog>
    <dialog ref={victoryRef} className="reset-dialog victory-dialog" aria-labelledby="victory-title" onCancel={e=>e.preventDefault()}>
      <span className="victory-medal"><Trophy size={34} aria-hidden="true"/></span>
      <p className="small-label">{ranks.length===1?'첫 번째 축제가 열렸어요!':'2위 결정전이 끝났어요!'}</p>
      <h2 id="victory-title">{ranks.length===1?`${(ranks[0]??0)+1}번 마을이 가장 먼저 축제를 개최해 승리합니다!`:`${(ranks[1]??0)+1}번 마을이 두 번째로 축제를 개최해 2위가 됩니다!`}</h2>
      <p>{ranks.length===1?'남은 마을끼리 2위 결정전을 이어갈까요? 1위 마을은 이후 차례에서 빠져요.':'1위와 2위가 결정됐어요. 결과를 확인하고 축제를 마쳐요.'}</p>
      <div>{ranks.length===1&&<button onClick={()=>dispatch({type:'continue'})}>2위 결정전 이어가기</button>}<button onClick={()=>dispatch({type:'end'})}>{ranks.length===1?'여기서 종료':'결과 확인'}</button></div>
    </dialog>
    <span className="sr-only" role="status">{playing?`${turn+1}번 마을의 차례, 부스 ${done}개 완성`:phase==='ended'?'게임이 종료됐어요.':''}</span>
  </main>;
}
