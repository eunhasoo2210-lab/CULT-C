export type Slots = [string | null, string | null];
export type Game = {
  count: number;
  phase: 'setup' | 'playing' | 'celebrating' | 'ended';
  turn: number;
  round: number;
  villages: Slots[][];
  draft: { booth: number; slots: Slots } | null;
  selected: string | null;
  ranks: number[];
  notice: string;
};
export type Action =
  | { type: 'count'; count: number }
  | { type: 'select'; card: string }
  | { type: 'place' | 'remove'; booth: number; slot: number }
  | { type: 'start' | 'reset' | 'cancel' | 'commit' | 'pass' | 'continue' | 'end' };
export const cards = Array.from({ length: 8 }, (_, i) => `카드 ${i + 1}`);
export const complete = (slots: Slots) => slots.every(Boolean);
export function initialGame(): Game {
  return { count: 3, phase: 'setup', turn: 0, round: 1,
    villages: Array.from({ length: 4 }, () => Array.from({ length: 4 }, (): Slots => [null, null])),
    draft: null, selected: null, ranks: [], notice: '' };
}
export function hand(game: Game) {
  const used = new Set(game.villages[game.turn].flat().filter(Boolean));
  game.draft?.slots.forEach(card => { if (card) used.add(card); });
  return cards.filter(card => !used.has(card));
}
function nextTurn(game: Game): Game {
  let next = (game.turn + 1) % game.count;
  for (let i = 0; i < game.count && game.ranks.includes(next); i++) next = (next + 1) % game.count;
  return { ...game, turn: next, round: game.round + Number(next <= game.turn), draft: null, selected: null };
}
export function gameReducer(game: Game, action: Action): Game {
  if (action.type === 'reset') return initialGame();
  if (action.type === 'count') return game.phase === 'setup' && [3, 4].includes(action.count) ? { ...game, count: action.count } : game;
  if (action.type === 'start') return game.phase === 'setup' ? { ...game, phase: 'playing', notice: '손의 예시 카드를 고른 뒤 부스의 빈칸을 눌러 주세요.' } : game;
  if (action.type === 'end') return { ...game, phase: 'ended', draft: null, selected: null };
  if (action.type === 'continue') return game.phase === 'celebrating' && game.ranks.length === 1
    ? nextTurn({ ...game, phase: 'playing', notice: '1위 마을은 차례에서 빠져요. 남은 마을끼리 2위를 정해요.' }) : game;
  if (game.phase !== 'playing') return game;
  switch (action.type) {
    case 'select':
      return hand(game).includes(action.card) ? { ...game, selected: game.selected === action.card ? null : action.card } : game;
    case 'place': {
      if (!game.selected || !hand(game).includes(game.selected)) return { ...game, notice: '먼저 손에 있는 예시 카드를 골라 주세요.' };
      if (game.draft && game.draft.booth !== action.booth) return { ...game, notice: '이번 턴에는 한 부스에만 넣을 수 있어요. 부스를 바꾸려면 넣기 선택을 취소해 주세요.' };
      if (game.villages[game.turn][action.booth][action.slot] || game.draft?.slots[action.slot]) return game;
      const slots: Slots = game.draft ? [...game.draft.slots] : [null, null];
      slots[action.slot] = game.selected;
      return { ...game, selected: null, draft: { booth: action.booth, slots }, notice: '같은 부스에 한 장 더 고르거나, 카드 넣기를 확정해 턴을 끝내세요.' };
    }
    case 'remove': {
      if (game.draft?.booth === action.booth && game.draft.slots[action.slot]) {
        const slots: Slots = [...game.draft.slots]; slots[action.slot] = null;
        return { ...game, draft: slots.some(Boolean) ? { booth: action.booth, slots } : null, notice: '넣기 선택을 취소했어요.' };
      }
      if (!game.villages[game.turn][action.booth][action.slot]) return game;
      const villages = game.villages.map((v, i) => i !== game.turn ? v : v.map((b, j): Slots => j !== action.booth ? b : [action.slot === 0 ? null : b[0], action.slot === 1 ? null : b[1]]));
      return { ...game, villages, notice: '카드를 손으로 돌려받았어요. 다른 부스의 카드도 더 뺄 수 있어요.' };
    }
    case 'cancel': return { ...game, draft: null, selected: null, notice: '넣기 선택을 취소했어요. 이미 뺀 카드는 손에 남아요.' };
    case 'pass': return game.draft ? game : nextTurn({ ...game, notice: '카드를 넣지 않고 차례를 넘겼어요.' });
    case 'commit': {
      if (!game.draft || !game.draft.slots.some(Boolean)) return game;
      const draft = game.draft;
      const villages = game.villages.map((v, i) => i !== game.turn ? v : v.map((b, j): Slots => j !== draft.booth ? b : [draft.slots[0] ?? b[0], draft.slots[1] ?? b[1]]));
      const updated: Game = { ...game, villages, draft: null, selected: null, notice: `${game.turn + 1}번 마을이 카드 ${draft.slots.filter(Boolean).length}장을 넣고 턴을 마쳤어요.` };
      if (villages[game.turn].every(complete)) return { ...updated, ranks: [...game.ranks, game.turn], phase: 'celebrating' };
      return nextTurn(updated);
    }
    default: return game;
  }
}
